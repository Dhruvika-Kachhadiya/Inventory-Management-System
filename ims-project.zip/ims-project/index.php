<?php 
 if(isset($_SESSION['user_id'])){
  header("location:admin/dashboard.php");
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Welcome to the IMS Project - A PHP and MySQL-based Inventory Management System">
  <meta name="author" content="">

  <title>IMS Project using PHP and MySQL</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link rel="stylesheet" href="css/one-page.css">

</head>

<body>

 <!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#"><img src="img\logo.png" alt="ims"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive"
        aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="admin/login.php">Admin Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="user/register.php">User Registration</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="user/login.php">User Login</a>
          </li>
        </ul>
      </div>
    </div>
</nav>


  <!-- Header with Background Image -->
  <section class="masthead text-center ">
    <div class="masthead-content">
      <div class="container">
        
        <h3 class="masthead-heading mb-3">Inventory Management System</h3>
        <h3 class=" mb-0 content">Welcome to our IMS. Streamline your business operations with our
          powerful PHP and MySQL-based solution.</h3>
      </div>
    </div>
	</div>
   
  </section>

  <!-- Footer -->
  <footer class="py-3 bg-black text-white">
    <div class="container">
      <p class="m-0 text-center">Designed and Developed By Dhruvika and Kashish IMS 2024</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>