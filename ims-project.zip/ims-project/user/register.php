<?php
// require('connection.php');

$usernameError = $emailError = $passwordError = $confirmpassError = "";

if (isset($_POST['submit1'])) {
    $username = stripslashes($_POST['username']);
    $username = mysqli_real_escape_string($con, $username);
    $email = stripslashes($_POST['email']);
    $email = mysqli_real_escape_string($con, $email);
    $password = stripslashes($_POST['password']);
    $password = mysqli_real_escape_string($con, $password);
    $confirmPassword = stripslashes($_POST['confirm_password']);
    $confirmPassword = mysqli_real_escape_string($con, $confirmPassword);

    // Validate username (required)
    if (empty($username)) {
        $usernameError = "Please Enter Username";
    }

    // Validate email (required and format)
    if (empty($email)) {
        $emailError = "Please Enter Email";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailError = "Invalid email format";
    }

    // Validate password (required and length)
    if (empty($password)) {
        $passwordError = "Please Enter Password";
    } elseif (strlen($password) < 6) {
        $passwordError = "Password must be at least 6 characters";
    }

    if (empty($confirmPassword)) {
        $confirmpassError = "Please Enter Confirm Password";
    }

    // Check if password and confirm password match
    if ($password !== $confirmPassword) {
        $confirmpassError = "Passwords do not match";
    }

    if (empty($usernameError) && empty($emailError) && empty($passwordError) && empty($confirmpassError)) {
        // Check if email already exists
        $check_query = "SELECT * FROM `reglogin` WHERE email='$email'";
        $check_result = mysqli_query($con, $check_query);

        if (mysqli_num_rows($check_result) > 0) {
            $emailError = "Email already exists. Please choose a different email.";
        } else {
            $query = "INSERT INTO `reglogin` (username, password, email)
                      VALUES ('$username', '" . md5($password) . "', '$email')";
            $result = mysqli_query($con, $query);

            if ($result) {
                // Set the admin session variable
                $_SESSION["user"] = $email;

                echo "<div class='form'>
                      <h3 style='color: white; margin-left:50px;'>You are registered successfully.</h3><br/>
                      <h4 class='link'  style='color: white;margin-left:50px;'>Click here to <a href='login.php' style='color:pink;font-weight:bold;'>Login</a></h4>
                      </div>";
            } else {
                echo "<div class='form'>
                      <h3 style='color: red; margin-left:50px; '>Registration failed. Please try again later.</h3><br/>
                      <h4 class='link' style='color: red;margin-left:50px; '>Click here to <a href='registration.php' style='color:pink;font-weight:bold;'>Registration</a> again.</h4>
                      </div>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Registration - php inventory management system</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
    <link rel="stylesheet" href="css/login.css" />
    <link href="css/all.min.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

</head>

<body>
    <div id="loginbox">
        <form name="form1" class="form-vertical" action="" method="post">
            <div class="control-group normal_text">
                <h3>User Registration Form</h3>
            </div>
            <div class="control-group">
                <div class="controls">
                    <div class="main_input_box">
                        <span class="add-on bg_lg"><i class="fa-solid fa-user"> </i></span><input type="text"
                            placeholder="Enter Username" name="username" />
                    </div>
                    <?php
                    if (!empty($usernameError)) {
                        echo "<p class='text-danger'>$usernameError</p>";
                    }
                    ?>
                </div>
            </div>
            <div class="control-group">
                <div class="controls">
                    <div class="main_input_box">
                        <span class="add-on bg_lg"><i class="fas fa-envelope"></i></span><input type="text"
                            placeholder="Enter Email" name="email" />
                    </div>
                    <?php
                    if (!empty($emailError)) {
                        echo "<p class='text-danger'>$emailError</p>";
                    }
                    ?>
                </div>
            </div>
            <div class="control-group">
                <div class="controls">
                    <div class="main_input_box">
                        <span class="add-on bg_ly"><i class="fas fa-lock"></i></span><input type="password"
                            placeholder="Password" name="password" />
                    </div>
                    <?php
                    if (!empty($passwordError)) {
                        echo "<p class='text-danger'>$passwordError</p>";
                    }
                    ?>
                </div>
            </div>
            <div class="control-group">
                <div class="controls">
                    <div class="main_input_box">
                        <span class="add-on bg_ly"><i class="fas fa-lock"></i></span><input type="password"
                            placeholder="Confirm Password" name="confirm_password" />
                    </div>
                    <?php
                    if (!empty($confirmpassError)) {
                        echo "<p class='text-danger'>$confirmpassError</p>";
                    }
                    ?>
                </div>
                <div class="control-group">
                <div class="controls">
                    <label class="checkbox">
                        <input type="checkbox" name="agree_terms" /> <span class="text-white">I agree with the</span> <a
                        class='text-success'>Terms of Services</a>
                    </label>
                </div>
            </div>
            </div>
            
            <div class="form-actions">
                <center>
                    <input type="submit" name="submit1" value="Register" class="btn btn-success" />
                </center>
            </div>
            <p class="link login_link">Already Have an
            account?<a href="login.php" style=' font-size:17px; font-weight:bold; ' class='text-success login_register' >Login</a></p>
        </form>
        
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/matrix.login.js"></script>
</body>

</html>
