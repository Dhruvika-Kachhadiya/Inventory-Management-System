<?php
    include("header.php");
?>

<div class="dashboard-wrapper">
    
    <div class="container-fluid  dashboard-content">

            <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">Stock Report</h2>
                    <div class="page-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="dashboard.php" class="breadcrumb-link">Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="stock_report.php" class="breadcrumb-link">Stock Report</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->

            <div class="row">
            <!-- ============================================================== -->
            <!-- basic table  -->
            <!-- ============================================================== -->
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered first">
                                <thead>
                                    <tr>
                                        <th>Sr No</th>
                                        <th>Product Company</th>
                                        <th>Product Name</th>
                                        <th>Product Unit</th>
                                        <th>Packing Size</th>
                                        <th>Product Qty</th>
                                        <th>Product Selling Price</th>
                                        <th>Edit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Balaji Snacks Pvt. Ltd.</td>
                                        <td>Masala Wafer</td>
                                        <td>Grams</td>
                                        <td>100</td>
                                        <td>1</td>
                                        <td>10</td>
                                        <td><a href="#">Edit</a></td>
                                    </tr>
                                    <tr>
                                        <td>1</td>
                                        <td>Balaji Snacks Pvt. Ltd.</td>
                                        <td>Masala Wafer</td>
                                        <td>Grams</td>
                                        <td>100</td>
                                        <td>1</td>
                                        <td>10</td>
                                        <td><a href="#">Edit</a></td>
                                    </tr>
                                    <tr>
                                        <td>1</td>
                                        <td>Balaji Snacks Pvt. Ltd.</td>
                                        <td>Masala Wafer</td>
                                        <td>Grams</td>
                                        <td>100</td>
                                        <td>1</td>
                                        <td>10</td>
                                        <td><a href="#">Edit</a></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end basic table  -->
            <!-- ============================================================== -->
        </div>
    </div>
</div>


<?php
    include("footer.php");
?>