<?php
    include("header.php");
?>

<div class="dashboard-wrapper">
    
    <div class="container-fluid  dashboard-content">

        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">Return Report</h2>
                    <div class="page-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="dashboard.php" class="breadcrumb-link">Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="return_report.php" class="breadcrumb-link">Return Report</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->

        <div class="widget-head add_unit">
            <div class="widget-box">
                <div class="widget-content add_unit">
                    <form name="form1" class="form-horizontal">
                    <div class="control-group">
                            <label class="control-label">Select Start Date</label>
                            <div class="controls">
                                <input type="date">
                            </div>
                    </div>
                    <div class="control-group">
                            <label class="control-label">Select End Date</label>
                            <div class="controls">
                                <input type="date">
                            </div>
                    </div>  
                    <div class="form-actions">
                            <button type="submit" name="submit1" class="btn">Show Product With Expiry Dates From These Dates</button>
                            <button type="button" name="submit1" class="btn">Clear Search</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

            <div class="row">
            <!-- ============================================================== -->
            <!-- basic table  -->
            <!-- ============================================================== -->
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered first">
                                <thead>
                                    <tr>
                                        <th>Bill No	</th>
                                        <th>Return By</th>
                                        <th>Return Date</th>
                                        <th>Product Company</th>
                                        <th>Product Name</th>
                                        <th>Product Unit</th>
                                        <th>Packing Size</th>
                                        <th>Product Price</th>
                                        <th>Product Qty</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>00032</td>
                                        <td>cdmidhruvika@gmail.com</td>
                                        <td>2024-6-08</td>
                                        <td>Balaji Snacks Pvt. Ltd.</td>
                                        <td>Masala Wafer</td>
                                        <td>Grams</td>
                                        <td>100</td>
                                        <td>10</td>
                                        <td>1</td>
                                        <td>10</td>
                                    </tr>
                                    <tr>
                                        <td>00032</td>
                                        <td>cdmidhruvika@gmail.com</td>
                                        <td>2024-6-08</td>
                                        <td>Balaji Snacks Pvt. Ltd.</td>
                                        <td>Masala Wafer</td>
                                        <td>Grams</td>
                                        <td>100</td>
                                        <td>10</td>
                                        <td>1</td>
                                        <td>10</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end basic table  -->
            <!-- ============================================================== -->
        </div>
    </div>
</div>


<?php
    include("footer.php");
?>