<?php
    include("header.php");
?>

<div class="dashboard-wrapper">
    
    <div class="container-fluid  dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">Add New Party</h2>
                    <div class="page-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="dashboard.php" class="breadcrumb-link">Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="add_new_party.php" class="breadcrumb-link">Add New Party</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->

        <div class="widget-head add_unit">
                <div class="widget-box">
                    <div class="widget-title">
                        <h5>Add New Party</h5>
                    </div>
                    <div class="widget-content">
                        <form name="form1" class="form-horizontal">
                            <div class="control-group">
                                <label class="control-label">First Name :</label>
                                <div class="controls">
                                    <input type="text" class="input_field" placeholder="Enter First name" name="firstname" />
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Last Name :</label>
                                <div class="controls">
                                    <input type="text" class="input_field" placeholder="Enter Last name" name="lastname" />
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Business Name :</label>
                                <div class="controls">
                                    <input type="text" class="input_field" placeholder="Enter Business name" name="businessname" />
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Contact :</label>
                                <div class="controls">
                                    <input type="text" class="input_field" placeholder="Enter Contact No" name="contact" />
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Address :</label>
                                <div class="controls">
                                    <textarea class="input_field" name="address" placeholder="Enter Address"></textarea><br/>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">City :</label>
                                <div class="controls">
                                    <input type="text" class="input_field" placeholder="Enter City" name="city" />
                                </div>
                            </div>
                            <div class="form-actions">
                                <button type="submit" name="submit1" class="btn">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
        </div>

        
            <div class="row">
            <!-- ============================================================== -->
            <!-- basic table  -->
            <!-- ============================================================== -->
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered first">
                                <thead>
                                    <tr>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Business Name</th>
                                        <th>Contact</th>
                                        <th>Address</th>
                                        <th>City</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Kashish</td>
                                        <td>Khokhani</td>
                                        <td>Mosam Corporation</td>
                                        <td>4563232555</td>
                                        <td>65,Main Street</td>
                                        <td>Surat</td>
                                        <td><a href="#">Edit</a></td>
                                        <td><a href="#">Delete</a></td>
                                    </tr>
                                    <tr>
                                        <td>Kashish</td>
                                        <td>Khokhani</td>
                                        <td>Mosam Corporation</td>
                                        <td>4563232555</td>
                                        <td>65,Main Street</td>
                                        <td>Surat</td>
                                        <td><a href="#">Edit</a></td>
                                        <td><a href="#">Delete</a></td>
                                    </tr>
                                    <tr>
                                        <td>Kashish</td>
                                        <td>Khokhani</td>
                                        <td>Mosam Corporation</td>
                                        <td>4563232555</td>
                                        <td>65,Main Street</td>
                                        <td>Surat</td>
                                        <td><a href="#">Edit</a></td>
                                        <td><a href="#">Delete</a></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end basic table  -->
            <!-- ============================================================== -->
        </div>
    </div>
</div>


<?php
    include("footer.php");
?>