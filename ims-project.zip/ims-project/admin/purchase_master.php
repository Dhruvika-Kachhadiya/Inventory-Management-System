<?php
    include("header.php");
?>

<div class="dashboard-wrapper">
    
    <div class="container-fluid  dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">Add New Purchase</h2>
                    <div class="page-breadcrumb">   
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="dashboard.php" class="breadcrumb-link">Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="purchase_master.php" class="breadcrumb-link">Add New Purchase</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->

        <div class="widget-head add_unit">
                <div class="widget-box">
                    <div class="widget-title">
                        <h5>Add New Purchase</h5>
                    </div>
                    <div class="widget-content add_unit">
                        <form name="form1" class="form-horizontal">
                        <div class="control-group">
                                <label class="control-label">Select Company:</label>
                                <div class="controls">
                                    <select class=" " name="company_name">
                                        <option value="">--select Company</option>
                                        <option value="">Balaji</option>
                                    </select>
                                </div>
                        </div>

                        <div class="control-group">
                                <label class="control-label">Select Product Name :</label>
                                <div class="controls">
                                    <select class=" " name="company_name">
                                        <option value="">--select Product Name--</option>
                                        <option value="">Balaji</option>
                                    </select>
                                </div>
                        </div>

                        <div class="control-group">
                                <label class="control-label">Select Unit:</label>
                                <div class="controls">
                                    <select class=" " name="unit">
                                        <option value="">--Selecte Unit--</option>
                                        <option value="">Grams</option>
                                    </select>
                                </div>
                        </div>

                        <div class="control-group">
                                <label class="control-label">Select Packing Size:</label>
                                <div class="controls">
                                    <select class=" " name="unit">
                                        <option value="">--Selecte Packing Size--</option>
                                        <option value=""></option>
                                    </select>
                                </div>
                        </div>

                        <div class="control-group">
                                <label class="control-label">Enter Qty:</label>
                                <div class="controls">
                                    <input type="text" name="qty" id="qty" class=" " placeholder="Enter Qty:">
                                </div>

                            </div>

                            <div class="control-group">
                                <label class="control-label">Enter Price:</label>
                                <div class="controls">
                                    <input type="text" name="price" id="price" class=" " placeholder="Enter Price:">
                                </div>
                            </div>

                            <div class="control-group">
                                <label class="control-label"> Select Party Name:</label>
                                <div class="controls">
                                    <select class=" " name="party_name" id="party_name">
                                        <option value="">Select</option>
                                    </select>
                                </div>
                            </div>

                            <div class="control-group">
                                <label class="control-label"> Select Purchase Type:</label>
                                <div class="controls" id="purchase_type">
                                    <select class=" " name="purchase_type" id="purchase_type">
                                        <option value="Cash">Cash</option>
                                        <option value="Debit">Debit</option>
                                    </select>
                                </div>
                            </div>

                            <div class="control-group">
                                <label class="control-label">Enter Expiry Date:</label>
                                <div class="controls">
                                    <input type="date" name="dt" id="dt" class=" ">
                                </div>

                            </div>
                            <div class="form-actions">
                                <button type="submit" name="submit1" class="btn">Purchase Now</button>
                            </div>
                        </form>
                    </div>
                </div>
        </div>
    </div>
</div>


<?php
    include("footer.php");
?>