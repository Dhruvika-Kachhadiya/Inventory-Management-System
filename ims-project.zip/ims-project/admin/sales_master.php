<?php
    include("header.php");
?>

<div class="dashboard-wrapper">

    <div class="container-fluid  dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">Sale a product</h2>
                    <div class="page-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="dashboard.php"
                                        class="breadcrumb-link">Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="sales_master.php" class="breadcrumb-link">Sale a
                                        product</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->

        <div id="content">
	<form name="form1" action="" method="post" class="form-horizontal nopadding">
        <div class="container-fluid">
            
                <div class="row-fluid" style="min-height: 100px; padding:10px;">
                    <div class="span12">
                        <div class="widget-box sales-master">
                            <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                                <h5>Sale a Products</h5>
                            </div>

                            <div class="widget-content nopadding">


                                <div class=" span4">
                                    <br>

                                    <div>
                                        <label>Full Name</label>
                                        <input type="text" class="span12" name="full_name" required>
                                    </div>
                                </div>

                                <div class="span3">
                                    <br>

                                    <div>
                                        <label>Bill Type</label>
                                        <select class="span12" name="bill_type_header">
                                            <option>Cash</option>
                                            <option>Debit</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="span2">
                                    <br>

                                    <div>
                                        <label>Date</label>
                                        <input type="text" class="span12" name="bill_date" value="" readonly>
                                    </div>
                                </div>

							<div class="span2">
                                    <br>

                                    <div>
                                        <label>Bill No</label>
                                        <input type="text" class="span12" name="bill_no" value="" readonly>
                                    </div>
                                </div>
							

                            </div>
                        </div>

                    </div>
                </div>

                <div class="row-fluid" style="min-height: 100px; padding:10px;">
                    <h4>Select A Product</h4>
                    <div class="select-product">
                        <div class="span2">
                            <div>
                                <label>Product Company</label>
                                <select class="span11" name="company_name" id="company_name">
                                    <option>Select</option>
                                </select>
                            </div>
                        </div>

                        <div class="span2">
                            <div>
                                <label>Product Name</label>
                                <div id="product_name_div">
                                    <select class="span11">
                                        <option>Select</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="span1">
                            <div>
                                <label>Unit</label>
                                <div id="unit_div">
                                    <select class="span11">
                                        <option>Select</option>
                                    </select>
                                </div>

                            </div>
                        </div>

                        <div class="span2">
                            <div>
                                <label>Packing Size</label>
                                <div id="packing_size_div">
                                    <select class="span11">
                                        <option>Select</option>
                                    </select>
                                </div>
                            </div>
                        </div>


                        <div class="span1">
                            <div>
                                <label>Price</label>
                                <input type="text" class="span11" name="price" id="price" readonly value="0">
                            </div>
                        </div>

                        <div class="span1">
                            <div>
                                <label>Enter Qty</label>
                                <input type="text" class="span11" name="qty" id="qty" autocomplete="off">
                            </div>
                        </div>



                        <div class="span1">
                            <div>
                                <label>Total</label>
                                <input type="text" class="span11" name="total" id="total" value="0" readonly>
                            </div>
                        </div>

                        <div class="span1">
                            <div>
                                <input type="button" class="btn add-btn" value="Add">
                            </div>
                        </div>

                    </div>
                </div>

                <!-- end new row-->

            <div class="row-fluid" style="min-height: 100px; padding:10px;">
                <div class="span12">
                    <center>
                        <input type="submit" name="submit1" value="generate bill" class="btn add-btn">
                    </center>

                </div>
            </div>
        </div>
		</form>
    </div>



    </div>
</div>

<?php
    include("footer.php");
?>