<?php
    include("header.php");
?>

<div class="dashboard-wrapper">
    
    <div class="container-fluid  dashboard-content">

        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">Purchase Report</h2>
                    <div class="page-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="dashboard.php" class="breadcrumb-link">Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="purchase_report.php" class="breadcrumb-link">Purchase Report</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->

        <div class="widget-head add_unit">
            <div class="widget-box">
                <div class="widget-content add_unit">
                    <form name="form1" class="form-horizontal">
                    <div class="control-group">
                            <label class="control-label">Select Start Date</label>
                            <div class="controls">
                                <input type="date">
                            </div>
                    </div>
                    <div class="control-group">
                            <label class="control-label">Select End Date</label>
                            <div class="controls">
                                <input type="date">
                            </div>
                    </div>  
                    <div class="form-actions">
                            <button type="submit" name="submit1" class="btn">Show Product With Expiry Dates From These Dates</button>
                            <button type="button" name="submit1" class="btn">Clear Search</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        
            <div class="row w-100">
            <!-- ============================================================== -->
            <!-- basic table  -->
            <!-- ============================================================== -->
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered first">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Purchase By</th>
                                        <th>Product Company</th>
                                        <th>Product Name</th>
                                        <th>Product Unit</th>
                                        <th>Packing Size</th>
                                        <th>Product Qty</th>
                                        <th>Price</th>
                                        <th>Party Name</th>
                                        <th>Purchase Type</th>
                                        <th>Expiry Date</th>
                                        <th>Purchase Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>cdmikashish@gmail.com</td>
                                        <td>Balaji Snacks Pvt. Ltd.</td>
                                        <td>Masala Wafer</td>
                                        <td>Grams</td>
                                        <td>100</td>
                                        <td>1</td>
                                        <td>1</td>
                                        <td>Mosam Corporation</td>
                                        <td>Debit</td>
                                        <td>2023-01-12</td>
                                        <td>2023-10-08</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end basic table  -->
            <!-- ============================================================== -->
        </div>
    </div>
</div>


<?php
    include("footer.php");
?>