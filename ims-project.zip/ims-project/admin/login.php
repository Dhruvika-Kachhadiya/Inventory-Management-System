<?php 
    include('connection.php');
    if(isset($_SESSION['user_id'])){
        header("location:dashboard.php");
    }
    if(isset($_POST['submit']))
    {
        $email=$_POST['email'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM `admin` WHERE `email`='$email' and `password`='$password' ";
        $res = mysqli_query($con,$sql);

        $cnt = mysqli_num_rows($res);
        if($cnt==1){
            $data=mysqli_fetch_assoc($res);
            $_SESSION['user_id']=$data['id'];
            header("location:dashboard.php"); 
        }else{
            echo "Email and password are wrong..!" ;
        }
    }
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin Login</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
    <link href="css/all.min.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/login.css">
    
</head>

<body>
    <div id="loginbox">
        <form class="form-vertical" method="post">
            <div class="control-group normal_text">
                <h3>Admin Login Page</h3>
            </div>
            <div class="control-group">
                <div class="controls">
                    <div class="main_input_box">
                        <span class="add-on bg_lg"><i class="fa-solid fa-envelope"></i></span><input type="text"
                            placeholder="Enter Email" name="email" />
                    </div>
                </div>
            </div>
            <div class="control-group">
                <div class="controls">
                    <div class="main_input_box">
                        <span class="add-on bg_ly"><i class="fa-solid fa-lock"></i></span><input type="password"
                            placeholder="Password" name="password" />
                    </div>
                </div>
            </div>

            <div class="form-actions">
                <center>
                    <input type="submit" name="submit" value="Login" class="btn btn-success" />
                </center>
            </div>
			<!-- <p class="link login_link" >Don't Have an account?<a href="registration.php" class='text-success login_register'> Registration</a></p> -->
        </form>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/matrix.login.js"></script>
</body>

</html>
