<?php
    include('connection.php');
    if(isset($_POST['submit']))
    {
        echo '<pre>';
        print_r($_POST);

        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        $sql= "INSERT INTO `admin` (`name`, `email`, `password`) VALUES ('$name', '$email', '$password')";
        mysqli_query($con,$sql);
        header("location:../index.php");
    }

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Registration - php inventory management system</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
    <link rel="stylesheet" href="css/login.css" />
    <link href="css/all.min.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

</head>

<body>
    <div id="loginbox">
        <form class="form-vertical" method="post">
            <div class="control-group normal_text">
                <h3>Admin Registration Form</h3>
            </div>
            <div class="control-group">
                <div class="controls">
                    <div class="main_input_box">
                        <span class="add-on bg_lg"><i class="fa-solid fa-user"> </i></span><input type="text"
                            placeholder="Enter Username" name="name" />
                    </div>
                </div>
            </div>
            <div class="control-group">
                <div class="controls">
                    <div class="main_input_box">
                        <span class="add-on bg_lg"><i class="fas fa-envelope"></i></span><input type="text"
                            placeholder="Enter Email" name="email" />
                    </div>
                </div>
            </div>
            <div class="control-group">
                <div class="controls">
                    <div class="main_input_box">
                        <span class="add-on bg_ly"><i class="fas fa-lock"></i></span><input type="password"
                            placeholder="Password" name="password" />
                    </div>
                </div>
            </div>
            <div class="control-group">
                <div class="controls">
                    <label class="checkbox">
                        <input type="checkbox" name="agree_terms" /> <span class="text-white">I agree with the</span> <a
                        class='text-success'>Terms of Services</a>
                    </label>
                </div>
            </div>
            
            <div class="form-actions">
                <center>
                    <input type="submit" name="submit" value="Register" class="btn btn-success" />
                </center>
            </div>
            <p class="link login_link">Already Have an
            account?<a href="login.php" style=' font-size:17px; font-weight:bold; ' class='text-success login_register' >Login</a></p>
        </form>
        
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/matrix.login.js"></script>
</body>

</html>
