<?php
    include("header.php");
?>

<div class="dashboard-wrapper">
    
    <div class="container-fluid  dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">Party Report</h2>
                    <div class="page-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="dashboard.php" class="breadcrumb-link">Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="party_report.php" class="breadcrumb-link">Party Report</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->

        <div class="widget-head add_unit">
                <div class="widget-box">
                    <div class="widget-content add_unit">
                        <form name="form1" class="form-horizontal">
                        <div class="control-group">
                                <label class="control-label">Select Start Date</label>
                                <div class="controls">
                                    <input type="date">
                                </div>
                        </div>
                        <div class="control-group">
                                <label class="control-label">Select End Date</label>
                                <div class="controls">
                                    <input type="date">
                                </div>
                        </div>  
                        <div class="form-actions">
                                <button type="submit" name="submit1" class="btn">Show Product With Expiry Dates From These Dates</button>
                                <button type="button" name="submit1" class="btn">Clear Search</button>
                            </div>
                        </form>
                    </div>
                </div>
        </div>